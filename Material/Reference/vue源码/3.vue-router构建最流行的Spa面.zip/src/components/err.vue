<template>
    <div class="wrapper">
       <div class="content">404 NOT FOUND ,你的页面去火星啦。。。</div>
    </div> 
</template>

<script>
export default {
    data() {
        return {
            title: 'err'
        }
    }
}
</script>


<template>
    <div class="wrapper">
       <div class="content">我是{{title}}</div>
    </div> 
</template>

<script>
export default {
    data() {
        return {
            title: 'doc'
        }
    },
    beforeRouteEnter(to, from ,next) {
         next(vm => vm.title = 'newDoc')
        
    },
    beforeCreate() {
        console.log('beforeCreate')
    }
}
</script>


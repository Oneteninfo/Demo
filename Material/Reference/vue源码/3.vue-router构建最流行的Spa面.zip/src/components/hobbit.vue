<template>
    <div class="wrapper">
       <div class="content">我是{{title}}</div>
    </div> 
</template>

<script>
export default {
    data() {
        return {
            title: 'hobbit'
        }
    }
}
</script>


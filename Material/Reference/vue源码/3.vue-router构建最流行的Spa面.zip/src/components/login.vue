<template>
    <div class="wrapper">
        <button @click="login">点击登陆</button>
    </div>
</template>

<script>
export default {
    methods: {
        login() {
          var doc = this.$router.options.routes.filter(item => item.name == 'doc')[0]
          doc.meta.isLogin = true
        }
    }
}
</script>


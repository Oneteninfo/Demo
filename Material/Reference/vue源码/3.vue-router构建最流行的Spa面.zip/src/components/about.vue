<template>
    <div class="wrapper">
       <div class="content">我是{{title}}</div>
       <router-link to="/about/person" tag="p" class="link">perosn</router-link>
       <router-link to="/about/hobbit" tag="p">hobbit</router-link>
       <router-link to="/about/blog" tag="p">blog</router-link>
       <router-view class="view"></router-view>
    </div> 
</template>

<script>
export default {
    data() {
        return {
            title: 'about'
        }
    }
}
</script>

<style scoped>
     .wrapper > p {
         width: 100px;
         height: 100px;
         border: 1px solid #8ff;
         display: inline-block;
         line-height: 100px;
         text-align: center;
         cursor: pointer;
     }
</style>



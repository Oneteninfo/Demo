<template>
    <div class="wrapper">
       <div class="content">我是{{title}}</div>
       <div>房间id: {{$route.query.id}}</div>
       <div>成员id: {{$route.query.mum_id}}</div>
    </div> 
</template>

<script>
export default {
    data() {
        return {
            title: 'home'
        }
    },
    watch: {
        $route(to, from) {
             console.log(to)
             console.log(from)
        }
    }
}
</script>


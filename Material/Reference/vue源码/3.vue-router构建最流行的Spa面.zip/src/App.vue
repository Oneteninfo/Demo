<template>
   <div id="app">
     Welcome to duyi!!!
     <ul>
        <!-- /home/id/mumber/id -->
       <router-link :to="{name: 'home'}" tag="li" active-class="active-home" exact-active-class="exact-active">home</router-link>
       <router-link :to="{path: '/doc'}" tag="li">doc</router-link>
       <router-link :to="{path: '/about'}" tag="li">about</router-link>
       <router-link to="/login" tag="li">login</router-link>
     </ul>
     <transition :name="dir">
         <router-view class="bc"></router-view>
     </transition>
   </div>
</template>

<script>
export default {
    data() {
      return {
        dir: 'left'
      }
    },
    watch: {
      $route(to, from) {
            this.dir = to.meta.index < from.meta.index ? 'left' : 'right'
      }
    }
}
// 左             右
//  👈        👈
//  
</script>
     
<style>
    .right-enter {
       transform: translateX(100%);
    }
    .right-enter-to {
      transform: translateX(0);
    }
    .right-leave {
      transform: translateX(0);
    }
    .right-leave-to {
      transform: translateX(-100%);
    }
    .right-enter-active, .right-leave-active, .left-enter-active, .left-leave-active {
      transition: all 1s;
    }
    .left-enter {
       transform: translateX(-100%);
    }
    .left-enter-to {
      transform: translateX(0);
    }
    .left-leave {
      transform: translateX(0);
    }
    .left-leave-to {
      transform: translateX(100%);
    }

    .bc {
       background: #ff6;  
       height: 150px;  
       position: absolute;
       width: 100%;
    }
    ul > li {
      display: inline-block;
      width: 100px;
      height: 100px;
      line-height: 100px;
      text-align: center;
      list-style: none;
      border: 1px solid lime;
      cursor: pointer;
    }
    a {
      text-decoration: none;
    }

    .router-link-active {
       background: red;
    }

    .router-link-exact-active {
      background: gold;
    }
    .active-home {
      background: pink;
    }

</style> 



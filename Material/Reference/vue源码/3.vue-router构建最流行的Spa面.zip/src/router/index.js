import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

// import home from '../components/home'
import doc from '../components/doc'
import about from '../components/about'
import err from '../components/err'
import hobbit from '../components/hobbit'
import person from '../components/person'
import blog from '../components/blog'
import login from '../components/login'
const router = new VueRouter({
    routes: [
        {
            path: '/home',
            name: 'home',
            component: () => import('../components/home'),
            meta: {
                index: 1
            }
        },
        // /home/:id/mumber/:mum_id
        // /home/:id
        {
            path: '/doc',
            name: 'doc',
            component: doc,
            // beforeEnter(to, from, next){
            //     if(to.meta.isLogin) {
            //         next()
            //     }else {
            //         next('/login')
            //     }
            // },
            meta: {
                index: 2,
                isLogin: false
            }
        },
        {
            path: '/login',
            component: login,
            meta: {
                index: 4
            }
        },
        {
            path: '/about',
            name: 'about',
            meta: {
                index: 3
            },
            component: about,
            children: [
                {
                    path: 'person',
                    name: 'person',
                    component: person
                },
                {
                    path: 'hobbit',
                    name: 'hobbit',
                    component: hobbit
                },
                {
                    path: 'blog',
                    name: 'blog',
                    component: blog
                }
            ]
        }, 
        {
            path: '/err',
            component: err,
            name: 'err'
        },
        {
           path: '*',
           redirect(to) {
               if(to.path == '/') {
                   return {name: 'home', query: {id:666,mum_id: 777}}
               } else {
                   return {name: 'err'}
               }
           }
        }
    ],
    mode: 'hash',
    linkActiveClass: 'active',
    linkExactActiveClass: 'exact'
})

// router.beforeEach((to, from, next) => {
//     if(to.path == '/doc') {
//         if(to.meta.isLogin) {
//             next()
//         } else {
//             next({path: '/login', meta:{route: to}})
//         }
//     } else {
//       next()
//     }
    
// })
export default router


// url 风格     home/23/mumber/12355
// restful风格  home/:home_id/mumber/:id  params = {home_id: 23,id:12355}
// no restful   home?homeid=123&id=456        query = {homeid:123,id:456}

//note 导航守卫
// 1 针对于路由对象(new VueRouter({}))的守卫 beforeEach
// 2 针对单个路由(route数组中的每个路由)的守卫 beforeEnter
// 3 针对组件(component)的守卫 beforeRouteEnter